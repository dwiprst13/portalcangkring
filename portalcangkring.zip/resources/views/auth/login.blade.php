@extends('layouts.app')

@section('auth')
    <div class="col-md-8 col-lg-6 col-xxl-4 mx-auto">
        <div class="card shadow-lg border-0 rounded-lg overflow-hidden">
            <div class="card-body p-5">
                <div class="text-center mb-4">
                    <a href="/" class="d-block">
                        <img src="admin/assets/images/auth/logo.png" width="180" alt="Logo">
                    </a>
                </div>
                
                @if (session()->has('password-success'))
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        {{ session('password-success') }}
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                @endif

                @if ($errors->any())
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <ul class="mb-0">
                            @foreach ($errors->all() as $error)
                                <li>{{ $error }}</li>
                            @endforeach
                        </ul>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                @endif

                <form method="POST" action="{{ route('login') }}">
                    @csrf
                    <div class="mb-3">
                        <label for="email" class="form-label fw-bold">Email</label>
                        <input type="email" id="email" class="form-control" name="email" value="{{ old('email') }}"
                            required autocomplete="email" autofocus>
                    </div>

                    <div class="mb-3">
                        <label for="password" class="form-label fw-bold">Kata Sandi</label>
                        <div class="input-group">
                            <input type="password" id="password" class="form-control" name="password" required>
                            <button type="button" class="btn btn-outline-secondary" id="togglePassword">
                                👁
                            </button>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary w-100 py-2 fs-5 rounded">Masuk</button>
                </form>
                <div class="text-center mt-4">
                    <p class="mb-0">Kembali Ke <a href="/" class="text-primary fw-bold">Beranda</a></p>
                </div>
            </div>
        </div>
    </div>
@endsection
<!-- 
@push('scripts')
<script>
    document.addEventListener("DOMContentLoaded", function() {
        document.getElementById("togglePassword").addEventListener("click", function() {
            var passwordInput = document.getElementById("password");
            if (passwordInput.type === "password") {
                passwordInput.type = "text";
                this.innerHTML = "🔒"; // Ubah ikon ke gembok
            } else {
                passwordInput.type = "password";
                this.innerHTML = "👁"; // Kembali ke ikon mata
            }
        });
    });
</script>
@endpush -->