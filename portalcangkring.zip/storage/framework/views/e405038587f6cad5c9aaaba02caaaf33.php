<div class="py-6 px-6 text-center">
    <p class="mb-0 fs-4">Website Portal Dusun Cangkring Copyright 2025</p> By : <a href="">KKN-T UAA 2025</a>
  </div>

<!-- GAUSAH DIGANTI BROOOO -->
<!-- BUAT SENDIRI KALAU MAU GANTI INI --><?php /**PATH C:\laragon\www\portalcangkring\resources\views/admin/partials/footer.blade.php ENDPATH**/ ?>