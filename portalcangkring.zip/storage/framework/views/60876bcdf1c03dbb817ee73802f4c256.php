<?php $__env->startSection('content'); ?>
<section class="counts section-bg">
    <div class="container">
        <div class="section-title">
            <h2>Detail Program</h2>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="row p-4">
                        <div class="col-lg-4">
                            <img src="<?php echo e(asset('storage/' . $program->foto)); ?>" alt="Gambar Program" class="img-fluid">
                        </div>
                        <div class="col-lg-8">
                            <div class="card-body">
                                <h2 class="card-title"><b><?php echo e($program->program); ?></b></h2>
                                <p><?php echo $program->deskripsi; ?></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\portalcangkring\resources\views/program/detail.blade.php ENDPATH**/ ?>