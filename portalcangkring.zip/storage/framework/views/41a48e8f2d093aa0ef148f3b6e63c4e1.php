<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12 d-flex align-items-strech">
      <div class="card w-100">
        <div class="card-header bg-primary">
            <div class="row align-items-center">
                <div class="col-6">
                    <h5 class="card-title fw-semibold text-white">videoProfil</h5>
                </div>
                <div class="col-6 text-right">
                    <a href="/videoProfil" type="button" class="btn btn-warning float-end me-2" target="_blank">Live Preview</a>
                </div>
            </div>
        </div>
        
        <div class="card-body">
            <?php if(session()->has('success')): ?>
                <div class="alert alert-success" role="alert">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>

            <div class="row">
                <div class="col-lg-8">
                    <iframe width="100%" height="400" src="<?php echo e($videoProfile->url_video); ?>" frameborder="0" allowfullscreen></iframe>
                </div>
                <div class="col-lg-4">
                    <form method="POST" action="/admin/video-profile/<?php echo e($videoProfile->id); ?>">
                        <?php echo method_field('put'); ?>
                        <?php echo csrf_field(); ?>
    
                        <div class="col">
                            <div class="mb-3">
                                <label for="url_video" class="form-label">url_video <span style="color: red">*</span></label>
                                <input type="text" class="form-control" name="url_video" id="url_video" placeholder="https://www.youtube.com/embed/" value="<?php echo e(old('url_video', $videoProfile->url_video)); ?>">
                                <i><small>Gunakan Embed ! Contoh : https://www.youtube.com/embed/CCDemVVMzOo</small></i>
                                <?php $__errorArgs = ['url_video'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-primary m-1 float-end">Update</button>
                   </form>
                </div>
            </div>
              
        </div>

      </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\portalcangkring\resources\views/admin/video-profile/index.blade.php ENDPATH**/ ?>