<?php $__env->startSection('content'); ?>
    <section class="counts section-bg">
        <div class="section-title">
            <h2>Pengumuman</h2>
        </div>
        <div class="container">
            <div class="row">
                <?php $__currentLoopData = $pengumumans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pengumuman): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-4">
                        <div class="card mb-4">
                            <div class="card-body p-3">
                                <h5 class="card-title mb-3"><b><?php echo e($pengumuman->judul); ?></b></h5>
                                <span><i class="bi bi-stopwatch-fill"></i>
                                    <?php echo e($pengumuman->created_at->diffForHumans()); ?></span>
                                <p class="mt-3"><?php echo $pengumuman->excerpt; ?> <a
                                        href="/pengumuman/<?php echo e($pengumuman->slug); ?>">Selengkapnya</a></p>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="paginate my-3" style="text-align: center">
                <?php echo e($pengumumans->links()); ?>

            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\portalcangkring\resources\views//pengumuman/index.blade.php ENDPATH**/ ?>