

<?php $__env->startSection('content'); ?>
<section class="counts section-bg">
    <div class="container">
  
      <div class="section-title">
        <h2>Perangkat Dusun Cangkring</h2>
      </div>
  
      <div class="row">
        <?php $__currentLoopData = $perangkatDesa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $perangkat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="col-xl-3 my-3" data-aos="fade-up">
              <div class="member">
                <div class="pic"><img src="<?php echo e(asset('storage/' . $perangkat->foto)); ?>" class="img-fluid" alt=""></div>
                <div class="member-info">
                  <h4><?php echo e($perangkat->nama); ?></h4>
                  <span><?php echo e($perangkat->jabatan); ?></span>
                </div>
              </div>
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
      
    </div>
  </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\portalcangkring\resources\views/perangkat-desa/index.blade.php ENDPATH**/ ?>