<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12 d-flex align-items-strech">
      <div class="card w-100">
        <div class="card-header bg-primary">
            <div class="row align-items-center">
                <div class="col-6">
                    <h5 class="card-title fw-semibold text-white">Berita</h5>
                </div>
                <div class="col-6 text-right">
                    <a href="/admin/berita/create" type="button" class="btn btn-warning float-end">Tambah Berita</a>
                </div>
            </div>
        </div>
        
        <div class="card-body">
            <?php if(session()->has('success')): ?>
                <div class="alert alert-success" role="alert">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>

            <!-- Nav tabs -->
            <ul class="nav nav-tabs" id="myTabs" role="tablist">
                <li class="nav-item">
                    <a class="nav-link active" id="publish-tab" data-toggle="tab" href="#publish" role="tab" aria-controls="publish" aria-selected="true">Publish</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" id="draft-tab" data-toggle="tab" href="#draft" role="tab" aria-controls="draft" aria-selected="false">Draft</a>
                </li>
            </ul>

            <!-- Tab panes -->
            <div class="tab-content mt-3">
                <div class="tab-pane fade show active" id="publish" role="tabpanel" aria-labelledby="publish-tab">
                    <div class="row">
                        <div class="table-responsive">
                            <table id="table_id" class="table display">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Judul</th>
                                        <th>Isi</th>
                                        <th>Penulis</th>
                                        <th>Status</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $beritas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $berita): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td><?php echo e($berita->judul); ?></td>
                                            <td><?php echo e($berita->excerpt); ?></td>
                                            <td><?php echo e($berita->user->name); ?></td>
                                            <td>
                                                <?php if($berita->status->status == 'publish'): ?>
                                                    <span class="badge text-bg-success p-2"><?php echo e($berita->status->status); ?></span>
                                                <?php else: ?>
                                                    <span class="badge text-bg-warning p-2"><?php echo e($berita->status->status); ?></span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <a href="/berita/<?php echo e($berita->slug); ?>" type="button" target="_blank" class="btn btn-success mb-1"><i class="ti ti-eye-check"></i></a>
                                                <a href="/admin/berita/<?php echo e($berita->id); ?>/edit" type="button" class="btn btn-warning mb-1"><i class="ti ti-edit"></i></a>
                                                <form id="<?php echo e($berita->id); ?>" action="/admin/berita/<?php echo e($berita->id); ?>" method="POST" class="d-inline">
                                                    <?php echo method_field('delete'); ?>
                                                    <?php echo csrf_field(); ?>
                                                    <button type="button" class="btn btn-danger swal-confirm mb-1" data-form="<?php echo e($berita->id); ?>"><i class="ti ti-trash"></i></button>
                                                </form>
                                            </td>                                    
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <div class="tab-pane fade" id="draft" role="tabpanel" aria-labelledby="draft-tab">
                    <div class="row">
                        <div class="table-responsive">
                            <table id="table_draft" class="table display">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Judul</th>
                                        <th>Isi</th>
                                        <th>Penulis</th>
                                        <th>Status</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $beritaDraft; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $berita): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td><?php echo e($berita->judul); ?></td>
                                            <td><?php echo e($berita->excerpt); ?></td>
                                            <td><?php echo e($berita->user->name); ?></td>
                                            <td>
                                                <?php if($berita->status->status == 'publish'): ?>
                                                    <span class="badge text-bg-success p-2"><?php echo e($berita->status->status); ?></span>
                                                <?php else: ?>
                                                    <span class="badge text-bg-warning p-2"><?php echo e($berita->status->status); ?></span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <a href="/admin/berita/<?php echo e($berita->id); ?>/edit" type="button" class="btn btn-warning mb-1"><i class="ti ti-edit"></i></a>
                                                <form id="<?php echo e($berita->id); ?>" action="/admin/berita/<?php echo e($berita->id); ?>" method="POST" class="d-inline">
                                                    <?php echo method_field('delete'); ?>
                                                    <?php echo csrf_field(); ?>
                                                    <button type="button" class="btn btn-danger swal-confirm mb-1" data-form="<?php echo e($berita->id); ?>"><i class="ti ti-trash"></i></button>
                                                </form>
                                            </td>                                    
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>

      </div>
    </div>
</div>

<script>
    $(document).ready( function () {
        $('#table_id').DataTable();
        $('#table_draft').DataTable();
    });
</script>

<script>
    $(document).ready( function () {
        $('#myTabs a').on('click', function (e) {
            e.preventDefault();
            $(this).tab('show');
        });
    });
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\portalcangkring\resources\views/admin/berita/index.blade.php ENDPATH**/ ?>