

<?php $__env->startSection('auth'); ?>
    <div class="col-md-8 col-lg-6 col-xxl-4 mx-auto">
        <div class="card shadow-lg border-0 rounded-lg overflow-hidden">
            <div class="card-body p-5">
                <div class="text-center mb-4">
                    <a href="/" class="d-block">
                        <img src="admin/assets/images/auth/logo.png" width="180" alt="Logo">
                    </a>
                </div>
                
                <?php if(session()->has('password-success')): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <?php echo e(session('password-success')); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>

                <?php if($errors->any()): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <ul class="mb-0">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>

                <form method="POST" action="<?php echo e(route('login')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <label for="email" class="form-label fw-bold">Email</label>
                        <input type="email" id="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>"
                            required autocomplete="email" autofocus>
                    </div>

                    <div class="mb-3">
                        <label for="password" class="form-label fw-bold">Kata Sandi</label>
                        <div class="input-group">
                            <input type="password" id="password" class="form-control" name="password" required>
                            <button type="button" class="btn btn-outline-secondary" id="togglePassword">
                                👁
                            </button>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary w-100 py-2 fs-5 rounded">Masuk</button>
                </form>
                <div class="text-center mt-4">
                    <p class="mb-0">Kembali Ke <a href="/" class="text-primary fw-bold">Beranda</a></p>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<!-- 
<?php $__env->startPush('scripts'); ?>
<script>
    document.addEventListener("DOMContentLoaded", function() {
        document.getElementById("togglePassword").addEventListener("click", function() {
            var passwordInput = document.getElementById("password");
            if (passwordInput.type === "password") {
                passwordInput.type = "text";
                this.innerHTML = "🔒"; // Ubah ikon ke gembok
            } else {
                passwordInput.type = "password";
                this.innerHTML = "👁"; // Kembali ke ikon mata
            }
        });
    });
</script>
<?php $__env->stopPush(); ?> -->
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\portalcangkring\resources\views/auth/login.blade.php ENDPATH**/ ?>