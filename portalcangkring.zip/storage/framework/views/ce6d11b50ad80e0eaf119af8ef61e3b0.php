<?php $__env->startSection('content'); ?>
<section class="counts section-bg">
    <div class="container">
        <div class="section-title">
            <h2>Data Kependudukan</h2>
        </div>

        <hr>
      <div class="row my-4">
        <div class="section-title">
            <h2>Data Penduduk</h2>
        </div>
        <div>
            <div class="card">
                <div class="card-body">
                    <h5 style="text-align: center;">Cangkring memiliki penduduk sebanyak <b><?php echo e($jumlahTotal); ?></b> orang.</h5>
                </div>
            </div>
        </div>
    </div>
    
      <div class="row my-4">
        <div class="section-title">
            <h2>Data Jumlah Warga Per Rt</h2>
        </div>
        <div class="col-lg-4">
            <div class="card">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered">
                            <thead class="table-primary">
                                <tr>
                                    <th scope="col">Nama Rt</th>
                                    <th scope="col">Jumlah</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $penrts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $penrt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($penrt->rt); ?></td> <!-- Gunakan variabel perulangan yang benar -->
                                        <td><?php echo e($penrt->jumlah); ?></td> <!-- Pastikan kolom 'jumlah' ada dalam database -->
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                            <tfoot class="table-warning">
                                <tr>
                                    <td>Total </td>
                                    <td><?php echo e($totalPenRt); ?></td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>                    
                </div>
            </div>
        </div>
    
        <div class="col-lg-8">
            <div class="card">
                <div class="card-body">
                    <div>
                        <canvas id="penRtChart" style="height: 400px; overflow: auto;"></canvas>
                    </div>                          
                </div>
            </div>
        </div>
      </div>
    
      <div class="row my-4">
        <div class="section-title">
            <h2>Data Jenis Kelamin</h2>
        </div>
        <div class="col-lg-4">
            <div class="card">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered">
                            <thead class="table-primary">
                                <tr>
                                    <th scope="col">Jenis Kelamin</th>
                                    <th scope="col">Jumlah</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $dataJenisKelamins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dataJenisKelamins): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($dataJenisKelamins->jenis_kelamin); ?></td>
                                    <td><?php echo e($dataJenisKelamins->jumlah); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                            <tfoot class="table-warning">
                                <tr>
                                    <td>Total </td>
                                    <td><?php echo e($jumlahTotal); ?></td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>                    
                </div>
            </div>
        </div>
    
        <div class="col-lg-8">
            <div class="card">
                <div class="card-body">
                    <div>
                        <canvas id="jenisKelaminChart" style="max-height: 400px; overflow: auto;"></canvas>
                    </div>                          
                </div>
            </div>
        </div>
      </div>

      <div class="row my-4">
        <div class="section-title">
            <h2>Data Agama</h2>
        </div>
        <div class="col-lg-4">
            <div class="card">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered">
                            <thead class="table-primary">
                                <tr>
                                    <th scope="col">Agama</th>
                                    <th scope="col">Penganut</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $dataAgamas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agama): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($agama->agama); ?></td>
                                    <td><?php echo e($agama->penganut); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                            <tfoot class="table-warning">
                                <tr>
                                    <td>Total </td>
                                    <td><?php echo e($totalPenganut); ?></td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>                    
                </div>
            </div>
        </div>
    
        <div class="col-lg-8">
            <div class="card">
                <div class="card-body">
                    <div>
                        <canvas id="agamaChart"></canvas>
                    </div>                          
                </div>
            </div>
        </div>
      </div>
      <div class="row my-4">
        <div class="section-title">
            <h2>Data Pekerjaan</h2>
        </div>
        <div class="col-lg-4">
            <div class="card">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered">
                            <thead class="table-primary">
                                <tr>
                                    <th scope="col">Pekerjaan</th>
                                    <th scope="col">Jumlah</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $pekerjaans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pekerjaan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($pekerjaan->pekerjaan); ?></td>
                                    <td><?php echo e($pekerjaan->jumlah); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                            <tfoot class="table-warning">
                                <tr>
                                    <td>Total </td>
                                    <td><?php echo e($totalPekerjaan); ?></td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>                    
                </div>
            </div>
        </div>
    
        <div class="col-lg-8">
            <div class="card">
                <div class="card-body">
                    <div>
                        <canvas id="pekerjaanChart" style="max-height: 350px; overflow: auto;"></canvas>
                    </div>                          
                </div>
            </div>
        </div>
      </div>
    </div>
  </section>

  <script>
    const ctxPekerjaan = document.getElementById('pekerjaanChart');
    
    const labelPekerjaan  = <?php echo $labelPekerjaan; ?>;
    const dataPekerjaan   = <?php echo $jumlahPekerjaan; ?>;

    new Chart(ctxPekerjaan, {
        type: 'polarArea',
        data: {
            labels: labelPekerjaan,
            datasets: [{
                label: 'Jumlah Pekerjaan',
                data: dataPekerjaan,
                backgroundColor: [
                    'rgb(255, 99, 132)',
                    'rgb(75, 192, 192)',
                    'rgb(255, 205, 86)',
                    'rgb(201, 203, 207)',
                    'rgb(54, 162, 235)'
                ],
                hoverOffset: 4
            }]
        }
    });
</script>


  <script>
    const ctxAgama = document.getElementById('agamaChart');
    
    const labels = <?php echo $labels; ?>;
    const dataPenganut = <?php echo $dataPenganut; ?>;
    
    new Chart(ctxAgama, {
      type: 'bar',
      data: {
        labels: labels,
        datasets: [{
          label: 'Penganut Agama',
          data: dataPenganut,
          backgroundColor: [
            'rgba(255, 99, 132, 0.2)',
            'rgba(255, 159, 64, 0.2)',
            'rgba(255, 205, 86, 0.2)',
            'rgba(75, 192, 192, 0.2)',
            'rgba(54, 162, 235, 0.2)',
            'rgba(153, 102, 255, 0.2)',
            'rgba(201, 203, 207, 0.2)'
          ],
          borderColor: [
            'rgb(255, 99, 132)',
            'rgb(255, 159, 64)',
            'rgb(255, 205, 86)',
            'rgb(75, 192, 192)',
            'rgb(54, 162, 235)',
            'rgb(153, 102, 255)',
            'rgb(201, 203, 207)'
          ],
          borderWidth: 1
        }]
      },
      options: {
        scales: {
          y: {
            beginAtZero: true
          }
        }
      }
    });
  </script>
  
  <script>
    const ctxJenisKelamin = document.getElementById('jenisKelaminChart');
    const labelsJenisKelamin = <?php echo $labelsJenisKelamin; ?>;
    const jumlah = <?php echo $jumlah; ?>;

    new Chart(ctxJenisKelamin, {
        type: 'pie', 
        data: {
            labels: labelsJenisKelamin,
            datasets: [{
                label: 'Jumlah Jenis Kelamin',
                data: jumlah,
                backgroundColor: [
                    'rgb(54, 162, 235)',
                    'rgb(255, 99, 132)',
                ],
                hoverOffset: 4
            }]
        }
    });
</script>

<script>
    document.addEventListener("DOMContentLoaded", function () {
        const ctxPenRt = document.getElementById('penRtChart').getContext('2d');

        const labelPenRt = <?php echo json_encode($labelPenRt, 15, 512) ?>;
        const dataPenRt = <?php echo json_encode($jumlahPenRt, 15, 512) ?>;

        new Chart(ctxPenRt, {
            type: 'bar',
            data: {
                labels: labelPenRt,
                datasets: [{
                    label: 'Jumlah Penduduk Per RT',
                    data: dataPenRt,
                    backgroundColor: [
                        'rgb(255, 99, 132)',
                        'rgb(75, 192, 192)',
                        'rgb(255, 205, 86)',
                        'rgb(201, 203, 207)',
                        'rgb(54, 162, 235)'
                    ],
                    hoverOffset: 4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    });
</script>


  
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\portalcangkring\resources\views/data-desa/index.blade.php ENDPATH**/ ?>